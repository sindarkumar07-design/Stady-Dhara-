# APK banane ka sabse aasan tareeka (Android Studio ke bina)

GitHub ka free cloud aapke liye APK bana deta hai. Sirf browser chahiye.

1. github.com par free account banao. "New repository" banao (naam: study-dhara, Private rakhna behtar).
2. Is zip ke andar ke saare files repository me upload karo ("Add file" > "Upload files"). Folder `app` aur baaki files sab.
3. Agar `.github` folder upload na ho (hidden folder), to "Add file" > "Create new file" dabao, naam likho:
   .github/workflows/build-apk.yml
   aur neeche wala text paste karo, phir Commit.

```
name: Build Android APK
on:
  workflow_dispatch: {}
  push:
    branches: [ main, master ]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'
      - name: Build APK
        run: gradle assembleDebug --no-daemon
      - uses: actions/upload-artifact@v4
        with:
          name: StudyDhara-APK
          path: app/build/outputs/apk/debug/app-debug.apk
```

4. Repository me "Actions" tab kholo > "Build Android APK" > "Run workflow".
5. 3-5 minute baad run ke andar "StudyDhara-APK" artifact dikhega. Download karo (zip hoga, andar app-debug.apk).
6. APK phone me install karo (Settings me "Install unknown apps" us file manager ke liye allow karo). Dusre phone me bhejne ke liye app ke Settings me "📤 Share" > "📦 APK" dabao.

Dhyan:
- Ye "debug" APK hai: apne aur dusre phones par chalane/share karne ke liye theek. Play Store ke liye Android Studio me "Generate Signed App Bundle" se signed .aab banana padega (README dekho).
- Maine ye workflow chalakar test nahi kiya. Agar koi error aaye to Actions ka log mujhe bhej do.
