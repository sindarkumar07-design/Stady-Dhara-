# Study Dhara: Android project (builds the APK / AAB)

## Easiest way (about 10 minutes)
1. Install Android Studio (free, from developer.android.com/studio).
2. File > Open > choose this folder (study-dhara-android). Wait for "Gradle sync" to finish. Accept any "update" prompts for Gradle/AGP.
3. Open app/build.gradle and change applicationId from com.yourname.studydhara to your own id (also the `package` line in MainActivity.java and `namespace`, or use Refactor > Rename).
4. Test APK: Build > Build Bundle(s) / APK(s) > Build APK(s). File: app/build/outputs/apk/debug/app-debug.apk. Install it only on your own phone to test.
5. Play Store file: Build > Generate Signed App Bundle / APK > Android App Bundle > Create new keystore. Save the keystore + passwords in 2 safe places (never share, never put in the project). Choose "release". Upload the .aab in Play Console (turn on Play App Signing).

## What is inside
- app/src/main/assets/www/index.html : the Study Dhara app
- MainActivity.java : secure WebView (no file access, no mixed content, Safe Browsing on, other links open in the browser)
- AndroidManifest.xml : ZERO permissions, backup off, no cleartext traffic

## Known limits of this wrapper
- AI buddy and AI test only work on claude.ai. For your own app, move them to your server (API key stays on the server) and add the INTERNET permission.
- Files you upload inside class rooms are stored on THIS phone only. Opening a PDF saves it to Downloads and opens your PDF app.
- minSdk is 29 (Android 10+) so no storage permission is needed.
- Data is demo/local until you connect a real backend and login.

## Before Play Store
Privacy policy URL, Data safety form, content rating, UGC rules for chat (report/block/moderation), closed testing. See the PWA package README.



## Owner build and student build
In index.html (app/src/main/assets/www/index.html) the top DEFAULTS has ALLOW_CLAIM:true.
- Your OWNER build: keep ALLOW_CLAIM:true. Install it on your phone, open Home and tap "Claim owner".
- STUDENT build: set ALLOW_CLAIM:false before building. Students then never see the claim button.
Data is stored on each phone separately until you connect a real backend, so the owner powers only apply on the phone where you claimed them.

## Share to another phone
Settings > Share: sends a text/link (set SHARE_URL on the System page or in DEFAULTS to your Play Store or website link).
Settings > Share > APK (Android app only): sends the installed APK file to another phone via WhatsApp/Bluetooth/etc. The other phone must allow "Install unknown apps". For Play-installed copies, share the Play Store link instead.
See BUILD-APK-ON-GITHUB.md to build the APK without Android Studio.

## Play Store target
The project targets Android 16 (API 36), which Google Play requires for new apps. See ../play-store/3-PLAY-STORE-CHECKLIST.md (inside the Play Store zip).
