# Privacy Policy (template, fill in and have it reviewed)

App: Study Dhara  |  Contact: YOUR_EMAIL  |  Last updated: YYYY-MM-DD

**What we collect:** name, class, optional profile photo, messages you post in class chats, test scores. (Edit to match your real backend.)
**Why:** to run class chats, show your progress, and let you use the AI study buddy.
**AI buddy:** questions you type may be sent to an AI service to produce answers. Do not share personal information.
**Who sees it:** classmates see your name, photo and messages in chat. Admins can remove content.
**Children:** students under 18 should use the app with a parent or teacher's knowledge. We do not sell data or show ads.
**Delete your data:** email YOUR_EMAIL or use Settings > Reset my profile. We delete account data within 30 days.
**Security:** data is sent over HTTPS. No password or secret is stored in the app.
