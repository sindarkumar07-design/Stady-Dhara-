# Study Dhara: install + Play Store guide

## 1. Folder
index.html, manifest.webmanifest, sw.js, icon-*.png, .well-known/assetlinks.json, privacy-policy-template.md

## 2. Test on your computer
python3 -m http.server 8080   -> open http://localhost:8080  (Chrome: menu > Install app)

## 3. Put it online (HTTPS is required)
Upload this folder to Netlify / Vercel / Firebase Hosting / GitHub Pages. You get https://yourapp.example.
Phones can now install it directly:
- Android (Chrome): menu > Install app / Add to Home screen.
- iPhone (Safari): Share > Add to Home Screen.

## 4. Play Store (Android)
1. Create a Google Play Console account (one-time fee). Verify identity.
2. Go to pwabuilder.com, enter your https URL, choose Android, fill the package id (e.g. com.yourname.studydhara). It builds a signed .aab (Trusted Web Activity). Keep the keystore file and passwords safe and backed up. Never share them.
3. Put the signing SHA-256 fingerprint into .well-known/assetlinks.json and re-deploy (this removes the browser bar).
4. Play Console > create app > upload the .aab > turn on Play App Signing.
5. Fill: Privacy policy URL, Data safety form, Content rating, Target audience (students 13+), and the User Generated Content declaration (chat).
6. Test with a closed test first. New personal accounts need a closed test with several testers for a number of days before production. Check Google's current rule.

## 5. iPhone App Store (optional)
Needs a Mac, Xcode and the Apple Developer Program (yearly fee). Wrap with Capacitor (npm i @capacitor/core @capacitor/cli; npx cap add ios). Apple may reject apps that are only a website wrapper, so most people ship iPhone users the Home Screen install above.

## 6. Before real launch (must do)
- Replace demo storage with a real backend and real login (Firebase/Supabase). Role checks must run on the server.
- Chat between students needs: report button, block user, moderator tools, profanity filter, and a way to contact you.
- Move the AI buddy and AI test generator to your own server that holds the API key (the claude.ai-only version does not work outside claude.ai).
- Host the privacy policy (template included) at a public URL.
- Ask a parent/teacher/lawyer to review children's privacy rules for your country.
- Ship only through the Play Store / your own https site. Never share the .aab/.apk or keystore through random links.


